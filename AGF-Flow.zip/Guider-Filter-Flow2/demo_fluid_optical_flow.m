
close all;
clear;
%clc;

% parameter settings
%***********************************************************************************

 st = parameter_settings();
 
 st.lambda = 0.1;  % the weight of the regularization term
 st.theta = 1;     % a factor of a momentum term  in the data term optimization for fast convergence θ=1
   
 st.downsample_factor = 0.8; % a downsampling factor η=0.8
 st.neighbor_d = 7; % the size of the window d*d=7*7
 st.sigma_c = 2*7^2; % for color where sigma_c=7 
 st.sigma_d = 2*5^2;  % for distance where sigma_c=5
 st.eps = 0.2;       % ξ=0.2

 st.pyramid_factor = 0.5; % a downsampling factor for an original image pair to construct image pyramids
 st.warps = 5; % the number of warps per level
 st.max_its = 10; % the number of iterations per warp
 S=0; 
 
%Please select an image type
%***********************************************************************************

%fluid_type ='Poiseuille'; %gradient flow
%fluid_type ='Lamb-Oseen'; %Rotation + Divergence
%fluid_type ='Uniform';    %Translation motion
%fluid_type ='Sink';       %Divergence motion
%fluid_type ='Vortex';     %Rotation motion

%fluid_type ='DNS turbulence';
%fluid_type ='SQG';
%fluid_type ='JHTDB-iso';
%fluid_type ='JHTDB-channel';
%fluid_type ='JHTDB-hd';
%fluid_type ='JHTDB-mhd';
%fluid_type ='particle';
%fluid_type ='scalar';

%fluid_type ='Typhoon';
fluid_type ='White Ovals';

if strcmp(fluid_type,'Poiseuille')
fprintf(fluid_type);    
I1 = imread('data/a1b_10.tif');
I2 = imread('data/a1b_11.tif');
groundtruthpath = 'data/a1b_sol.flo';
outflowpath='data/a1b_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 2.8;
streamlines_factor = 4;
S = 0;
end

if strcmp(fluid_type,'Lamb-Oseen')
fprintf(fluid_type);    
I1 = imread('data/a2b_10.tif');
I2 = imread('data/a2b_11.tif');
groundtruthpath = 'data/a2b_sol.flo';
outflowpath='data/a2b_flow.flo';
groundtruth='true';
downsample = 30;
flow_scale = 1.5;
streamlines_factor = 4;
S = 0;
end

if strcmp(fluid_type,'Uniform')
fprintf(fluid_type);    
I1 = imread('data/a3b_10.tif');
I2 = imread('data/a3b_11.tif');
groundtruthpath = 'data/a3b_sol.flo';
outflowpath='data/a3b_flow.flo';
groundtruth='true';
downsample = 20;
flow_scale = 0.5;
streamlines_factor = 4;
S = 0;
end

if strcmp(fluid_type,'Sink')
fprintf(fluid_type);    
I1 = imread('data/a4b_10.tif');
I2 = imread('data/a4b_11.tif');
groundtruthpath = 'data/a4b_sol.flo';
outflowpath='data/a4b_flow.flo';
groundtruth='true';
downsample = 22;
flow_scale = 5;
streamlines_factor = 4;
S = 0;
end



if strcmp(fluid_type,'Vortex')
fprintf(fluid_type);    
I1 = imread('data/a5b_10.tif');
I2 = imread('data/a5b_11.tif');
groundtruthpath = 'data/a5b_sol.flo';
outflowpath='data/a5b_flow.flo';
groundtruth='true';
downsample = 20; %the number of flow vectors plot flow vectors
flow_scale = 5;
streamlines_factor = 4;
S = 0;
end



if strcmp(fluid_type,'DNS turbulence')
fprintf(fluid_type);
I1 = imread('data/DNS_turbulence_img1.tif');
I2 = imread('data/DNS_turbulence_img2.tif');
groundtruthpath = 'data/DNS_turbulence_gt.flo';
outflowpath = 'data/DNS_turbulence_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end

if strcmp(fluid_type,'SQG')
fprintf(fluid_type);
I1 = imread('data/SQG_00010_img1.tif');
I2 = imread('data/SQG_00010_img2.tif');
groundtruthpath = 'data/SQG_00010_flow.flo';
outflowpath = 'data/SQG_00010_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 0;
end

if strcmp(fluid_type,'JHTDB-iso')
fprintf(fluid_type);
I1 = imread('data/JHTDB_isotropic1024_hd_00010_img1.tif');
I2 = imread('data/JHTDB_isotropic1024_hd_00010_img2.tif');
groundtruthpath = 'data/JHTDB_isotropic1024_hd_00010_flow.flo';
outflowpath = 'data/JHTDB_isotropic1024_hd_00010_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end

if strcmp(fluid_type,'JHTDB-channel')
fprintf(fluid_type);
I1 = imread('data/JHTDB_channel_00010_img1.tif');
I2 = imread('data/JHTDB_channel_00010_img2.tif');
groundtruthpath = 'data/JHTDB_channel_00010_flow.flo';
outflowpath = 'data/JHTDB_channel_00010_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end

if strcmp(fluid_type,'JHTDB-hd')
fprintf(fluid_type);
I1 = imread('data/JHTDB_channel_hd_00010_img1.tif');
I2 = imread('data/JHTDB_channel_hd_00010_img2.tif');
groundtruthpath = 'data/JHTDB_channel_hd_00010_flow.flo';
outflowpath = 'data/JHTDB_channel_hd_00010_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end

if strcmp(fluid_type,'JHTDB-mhd')
fprintf(fluid_type);
I1 = imread('data/JHTDB_mhd1024_hd_00010_img1.tif');
I2 = imread('data/JHTDB_mhd1024_hd_00010_img2.tif');
groundtruthpath = 'data/JHTDB_mhd1024_hd_00010_flow.flo';
outflowpath = 'data/JHTDB_mhd1024_hd_00010_AGF_flow.flo';
groundtruth='true';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end


if strcmp(fluid_type,'particle')
I1 = imread('data/run010050260.tif');
I2 = imread('data/run010050270.tif');
outflowpath = 'data/run010050260_AGF_flow.flo';
groundtruth='false';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end

if strcmp(fluid_type,'scalar')
I1 = imread('data/run010052440.tif');
I2 = imread('data/run010052450.tif');
outflowpath = 'data/run010052440_AGF_flow.flo';
groundtruth='false';
downsample = 40;
flow_scale = 1.5;
streamlines_factor = 11;
S = 1;
end


if strcmp(fluid_type,'Typhoon')
I1 = imread('data/Typhoon_img1.png');
I2 = imread('data/Typhoon_img2.png');
outflowpath = 'data/Typhoon_AGF_flow.flo';
groundtruth='false';
downsample = 40;
flow_scale = 1.2;
streamlines_factor = 6;
S = 0;
end

if strcmp(fluid_type,'White Ovals')
I1 = imread('data/White_Ovals_img1.png');
I2 = imread('data/White_Ovals_img2.png');
outflowpath='data/White_Ovals_AGF_flow.flo';
groundtruth='false';
downsample = 40;
flow_scale = 1.7;
streamlines_factor = 13;
S = 0;
end




tic
[flow] = coarse_to_fine(I1, I2, st,S);
toc
u = flow(:, :, 1);
v = flow(:, :, 2);
writeFlowFile(flow, outflowpath)

% read the ground-truth flow
if strcmp(groundtruth,'true')
Gtflow = readFlowFile(groundtruthpath);
tu = Gtflow(:, :, 1);
tv = Gtflow(:, :, 2);
% compute the mean end-point error (mepe) and the mean angular error (mang)
UNKNOWN_FLOW_THRESH = 1e9;
[mang, mepe] = flowError(tu, tv, u, v, 0, 0.0, UNKNOWN_FLOW_THRESH);
fprintf('\n');
disp(['Mean end-point error: ', num2str(mepe)]);
disp(['Mean angular error: ', num2str(mang)]);

plot_flow(fluid_type,'Groundtruth-Flow',tu,tv,I1,downsample,flow_scale);
plot_streamlines(fluid_type,'Groundtruth-Streamlines',tu,tv,I1,streamlines_factor);
end

plot_image(fluid_type,I1,I2);
plot_flow(fluid_type,'AGF-Flow',u,v,I1,downsample,flow_scale);
plot_streamlines(fluid_type,'AGF-Streamlines',u,v,I1,streamlines_factor);
plot_velocity(fluid_type,'AGF-Velocity',u,v,downsample,flow_scale,streamlines_factor);
plot_vorticity(fluid_type,'AGF-Vorticity',u,v,downsample,flow_scale,streamlines_factor);



